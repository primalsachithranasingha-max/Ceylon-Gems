CEYLON GEMS WEBSITE
===================

Files:
- index.html
- css/style.css
- js/products.js
- js/main.js
- images/

HOW TO CUSTOMIZE
1. Open js/products.js and replace the sample products, prices and descriptions.
2. Replace each product image URL with your own real gemstone photo.
3. Update the WhatsApp number in index.html and js/main.js.
4. Update email and company contact details in index.html.
5. For production e-commerce checkout, connect a secure backend/payment gateway.

NOTE:
The sample image URLs are remote demonstration images. For your business, use your own licensed/real gemstone photographs.
The sample gemological claims are intentionally marked as sample/to be verified. Do not publish origin, treatment, certification or authenticity claims unless verified for each stone.
